<?php
// Connessione al database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "adam";

// Connessione al database
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica la connessione
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

// Inizializza le variabili per l'email e la password
$email = $password = "";
$email_err = $password_err = "";

// Verifica se il form è stato inviato
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Controlla se l'email è stata inserita
    if (empty(trim($_POST["email"]))) {
        $email_err = "Inserisci l'email.";
    } else {
        $email = trim($_POST["email"]);
    }

    // Controlla se la password è stata inserita
    if (empty(trim($_POST["password"]))) {
        $password_err = "Inserisci la password.";
    } else {
        $password = trim($_POST["password"]);
    }

    // Verifica le credenziali dell'utente
    if (empty($email_err) && empty($password_err)) {
        $sql = "SELECT id, email, password FROM utenti WHERE email = ?";

        if ($stmt = $conn->prepare($sql)) {
            // Bind dei parametri
            $stmt->bind_param("s", $param_email);
            $param_email = $email;

            // Esegui la query
            if ($stmt->execute()) {
                // Memorizza il risultato
                $stmt->store_result();

                // Verifica se l'email esiste, se sì verifica la password
                if ($stmt->num_rows == 1) {
                    // Bind dei risultati
                    $stmt->bind_result($id, $email, $hashed_password);
                    if ($stmt->fetch()) {
                        if (password_verify($password, $hashed_password)) {
                            // Password corretta, avvia una nuova sessione
                            session_start();

                            // Salva i dati dell'utente nella sessione
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["email"] = $email;

                            // Reindirizza alla pagina home
                            header("location: home.php");
                            exit;
                        } else {
                            // Mostra un errore se la password è sbagliata
                            $password_err = "La password inserita non è valida.";
                        }
                    }
                } else {
                    // Mostra un errore se l'email non è registrata
                    $email_err = "Nessun account trovato con questa email.";
                }
            } else {
                echo "Qualcosa è andato storto. Riprova più tardi.";
            }
            // Chiudi lo statement
            $stmt->close();
        }
    }
    // Chiudi la connessione al database
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            padding: 20px;
        }
        .login-container {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            background-color: #f9f9f9;
        }
        .login-container h2 {
            text-align: center;
        }
        .login-container input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .login-container button {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 4px;
            background-color: #5cb85c;
            color: white;
            font-size: 16px;
            margin-bottom: 10px;
        }
        .error {
            color: red;
            font-size: 0.9em;
        }
    </style>
</head>

<body>
    

    <div class="login-container">
        <h2>Login ADAM</h2>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="input-data">
                <label for="email">Email Address</label>
                <input type="email" name="email" value="<?php echo $email; ?>" required>
                <span class="error"><?php echo $email_err; ?></span>
            </div>
            <div class="input-data">
                <label for="password">Password</label>
                <input type="password" name="password" required>
                <span class="error"><?php echo $password_err; ?></span>
            </div>
            <button type="submit">Login</button>
        </form>
        <p>Non hai un account? <a href="/rumelea/adam/clinic/registrazione.php">Registrati qui</a>.</p>
    </div>
</body>

</html>
