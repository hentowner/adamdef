<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marker Information</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            padding: 20px;
        }
        .info-container {
            border: 1px solid #ccc;
            padding: 20px;
            border-radius: 8px;
            background-color: #f9f9f9;
        }
    </style>
</head>
<body>

<?php
// Dati di connessione al database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "adam";

// Crea la connessione al database
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica la connessione
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Recupera l'ID del marker dalla query string
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Prepara e esegue la query SQL
$sql = "SELECT name, address,  type FROM markers WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$stmt->bind_result($name, $address,  $type);

// Verifica se il marker esiste
if ($stmt->fetch()) {
    $marker = [
        'name' => $name,
        'address' => $address,
        
        'type' => $type
    ];
} else {
    echo "<p>Marker not found.</p>";
    exit;
}

// Chiudi la connessione
$stmt->close();
$conn->close();
?>

<div class="info-container">
    <h1><?php echo htmlspecialchars($marker['name']); ?></h1>
    <p><strong>Address:</strong> <?php echo htmlspecialchars($marker['address']); ?></p>
    
    <p><strong>Type:</strong> <?php echo htmlspecialchars($marker['type']); ?></p>
</div>

</body>
</html>

