<?php
session_start();

// Funzione per controllare se l'utente è loggato
function checkLogin() {
    // Supponiamo che tu abbia impostato una variabile di sessione 'loggedin' quando l'utente si logga
    if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
        return true;
    } else {
        return false;
    }
}

// Controlla lo stato di login dell'utente
if (checkLogin()) {
    // Se l'utente è loggato, reindirizzalo alla pagina dell'appuntamento
    header("Location: home.php");
    exit;
} else {
    // Se l'utente non è loggato, reindirizzalo alla pagina di login
    header("Location: login.php");
    exit;
}
?>
