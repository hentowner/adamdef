<?php
session_start();

// Verifica se l'utente è autenticato, altrimenti reindirizza alla pagina di login
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit;
}

// Connessione al database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "adam";

// Connessione al database
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica la connessione
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

// Prendi l'ID dell'utente dalla sessione
$id_utente = $_SESSION['id'];

// Query per selezionare gli ordini dell'utente specificato
$sql = "SELECT * FROM ordini WHERE id_utente = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_utente);
$stmt->execute();
$result = $stmt->get_result();

// Chiudi lo statement
$stmt->close();

// Chiudi la connessione al database
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>I Miei Ordini</title>
    <style>
        /* Inserisci qui il tuo CSS */
    </style>
</head>
<style>body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f5f5f5;
}

.container {
    max-width: 800px;
    margin: 20px auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h2 {
    color: #007bff;
    text-align: center;
}

table {
    width: 100%;
    border-collapse: collapse;
}

table th, table td {
    border: 1px solid #ddd;
    padding: 8px;
    text-align: left;
}

table th {
    background-color: #f2f2f2;
}

table tr:nth-child(even) {
    background-color: #f9f9f9;
}

table tr:hover {
    background-color: #f2f2f2;
}
</style>
<body>
    <h2>I Miei Ordini</h2>
    <table>
        <thead>
            <tr>
                <th>ID Ordine</th>
                <th>Nome Prodotto</th>
                <th>Indirizzo di Consegna</th>
                <th>Carta di Credito</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Verifica se ci sono ordini per l'utente
            if ($result->num_rows > 0) {
                // Output dei dati di ogni ordine
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["id_ordine"] . "</td>";
                    echo "<td>" . $row["nome_prodotto"] . "</td>";
                    echo "<td>" . $row["via"] . "</td>";
                    echo "<td>" . $row["carta_di_credito"] . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='4'>Nessun ordine trovato.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</body>

</html>
