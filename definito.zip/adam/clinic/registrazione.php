<?php
// Connessione al database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "adam";

// Connessione al database
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica la connessione
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

// Inizializza le variabili per la registrazione
$nome = $cognome = $email = $password = "";
$nome_err = $cognome_err = $email_err = $password_err = "";

// Verifica se il form è stato inviato
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Controlla se il nome è stato inserito
    if (empty(trim($_POST["nome"]))) {
        $nome_err = "Inserisci il nome.";
    } else {
        $nome = trim($_POST["nome"]);
    }

    // Controlla se il cognome è stato inserito
    if (empty(trim($_POST["cognome"]))) {
        $cognome_err = "Inserisci il cognome.";
    } else {
        $cognome = trim($_POST["cognome"]);
    }

    // Controlla se l'email è stata inserita
    if (empty(trim($_POST["email"]))) {
        $email_err = "Inserisci l'email.";
    } else {
        $email = trim($_POST["email"]);
    }

    // Controlla se la password è stata inserita
    if (empty(trim($_POST["password"]))) {
        $password_err = "Inserisci la password.";
    } else {
        $password = password_hash(trim($_POST["password"]), PASSWORD_DEFAULT); // Cripta la password utilizzando password_hash
    }

    // Verifica se ci sono errori di input prima di inserire nel database
    if (empty($nome_err) && empty($cognome_err) && empty($email_err) && empty($password_err)) {
        // Prepara e esegui l'istruzione SQL per l'inserimento
        $sql = "INSERT INTO utenti (nome, cognome, email, password) VALUES (?, ?, ?, ?)";

        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("ssss", $param_nome, $param_cognome, $param_email, $param_password);
            $param_nome = $nome;
            $param_cognome = $cognome;
            $param_email = $email;
            $param_password = $password;
            session_start();

            // Salva i dati dell'utente nella sessione
            $_SESSION["loggedin"] = true;
            $_SESSION["id"] = $id;
            $_SESSION["email"] = $email;
            if ($stmt->execute()) {
                // Reindirizza alla pagina home dopo la registrazione
                header("location: home.php");
                exit();
            } else {
                echo "Qualcosa è andato storto. Riprova più tardi.";
            }
            // Chiudi lo statement
            $stmt->close();
        }
    }
    // Chiudi la connessione al database
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrazione</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            padding: 20px;
        }
        .register-container {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            background-color: #f9f9f9;
        }
        .register-container h2 {
            text-align: center;
        }
        .register-container input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .register-container button {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 4px;
            background-color: #5cb85c;
            color: white;
            font-size: 16px;
            margin-bottom: 10px;
        }
        .error {
            color: red;
            font-size: 0.9em;
        }
    </style>
</head>

<body>
    <div class="register-container">
        <h2>Registrati in ADAM</h2>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="input-data">
                <label for="nome">First Name</label>
                <input type="text" name="nome" value="<?php echo $nome; ?>" required>
                <span class="error"><?php echo $nome_err; ?></span>
            </div>
            <div class="input-data">
                <label for="cognome">Last Name</label>
                <input type="text" name="cognome" value="<?php echo $cognome; ?>" required>
                <span class="error"><?php echo $cognome_err; ?></span>
            </div>
            <div class="input-data">
                <label for="email">Email Address</label>
                <input type="email" name="email" value="<?php echo $email; ?>" required>
                <span class="error"><?php echo $email_err; ?></span>
            </div>
            <div class="input-data">
                <label for="password">Password</label>
                <input type="password" name="password" required>
                <span class="error"><?php echo $password_err; ?></span>
            </div>
            <button type="submit">Registrati</button>
        </form>
    </div>
</body>

</html>
