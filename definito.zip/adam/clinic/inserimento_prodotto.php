<?php
session_start();

// Verifica se l'utente è autenticato, altrimenti reindirizza alla pagina di login
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit;
}
if($_SESSION["email"] != "admin@adam.it"){
    header("Location: home.php");
}

// Connessione al database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "adam";

// Verifica se il modulo è stato inviato
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Connessione al database
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Verifica la connessione
    if ($conn->connect_error) {
        die("Connessione fallita: " . $conn->connect_error);
    }

    // Prendi i dati dal modulo
    $nome_prodotto = $_POST["nome_prodotto"];
    $prezzo = $_POST["prezzo"];

    // Query per inserire il prodotto nel database
    $sql = "INSERT INTO prodotti (nome, prezzo) VALUES ('$nome_prodotto', '$prezzo')";

    if ($conn->query($sql) === TRUE) {
        header("Location: home.php");
    } else {
        echo "Errore durante l'inserimento del prodotto: " . $conn->error;
    }

    // Chiudi la connessione al database
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inserimento Prodotto</title>
</head>
<style>body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f5f5f5;
}

.container {
    max-width: 600px;
    margin: 20px auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h2 {
    margin-top: 0;
    color: #007bff;
}

form div {
    margin-bottom: 15px;
}

label {
    display: block;
    margin-bottom: 5px;
    color: #333;
}

input[type="text"],
input[type="number"] {
    width: calc(100% - 20px);
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

button[type="submit"] {
    padding: 10px 20px;
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

button[type="submit"]:hover {
    background-color: #0056b3;
}
</style>
<body>
    <h2>Inserimento Prodotto</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <div>
            <label for="nome_prodotto">Nome Prodotto:</label>
            <input type="text" name="nome_prodotto" required>
        </div>
        <div>
            <label for="prezzo">Prezzo:</label>
            <input type="number" name="prezzo" step="0.01" min="0" required>
        </div>
        <button type="submit">Inserisci Prodotto</button>
    </form>
</body>

</html>

