<?php
session_start();

// Verifica se l'utente è autenticato, altrimenti reindirizza alla pagina di login
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit;
}

// Controlla se è stato passato un ID del prodotto tramite il link
if (!isset($_GET['id']) || empty($_GET['id'])) {
    // Reindirizza indietro alla pagina dei prodotti se non è specificato un ID valido
    header("Location: catalogo.php");
    exit;
}

// Recupera l'ID del prodotto dall'URL
$id_prodotto = $_GET['id'];

// Connessione al database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "adam";

// Connessione al database
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica la connessione
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

// Query per selezionare il prodotto specificato
$sql = "SELECT nome, prezzo FROM prodotti WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_prodotto);
$stmt->execute();
$result = $stmt->get_result();

// Verifica se il prodotto è stato trovato


// Ottieni i dati del prodotto
$row = $result->fetch_assoc();
$nome_prodotto = $row['nome'];
$prezzo_prodotto = $row['prezzo'];

// Chiudi lo statement
$stmt->close();

// Verifica se il modulo è stato inviato
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Prendi i dati dal modulo
    $nome_cliente = $_POST["nome"];
    $email_cliente = $_POST["email"];
    $numero_carta = $_POST["numero_carta"];
    $indirizzo_consegna = $_POST["indirizzo"];
    $quantita = $_POST["quantita"];

    // Inserisci l'ordine nel database
    $sql_ordine = "INSERT INTO ordini (id_utente, nome_prodotto, via, carta_di_credito, quantita) VALUES (?, ?, ?, ?, ?)";
    $stmt_ordine = $conn->prepare($sql_ordine);
    $stmt_ordine->bind_param("isssi", $_SESSION['id'], $nome_prodotto, $indirizzo_consegna, $numero_carta, $quantita);

    // Esegui l'inserimento dell'ordine
    if ($stmt_ordine->execute()) {
        header("Location: home.php");
    } else {
        echo "Errore durante l'inserimento dell'ordine: " . $conn->error;
    }

    // Chiudi lo statement
    $stmt_ordine->close();
}

// Chiudi la connessione al database
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acquisto</title>
</head>
<style>
   body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f5f5f5;
}

.container {
    max-width: 600px;
    margin: 20px auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h2 {
    margin-top: 0;
    color: #007bff;
}

form {
    margin-top: 20px;
}

label {
    display: block;
    margin-bottom: 5px;
    color: #333;
}

input[type="text"],
input[type="email"],
textarea,
input[type="number"] {
    width: calc(100% - 20px);
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
    margin-bottom: 10px;
}

input[type="submit"] {
    padding: 10px 20px;
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type="submit"]:hover {
    background-color: #0056b3;
}
</style>


<body>
    <h2>Acquista <?php echo $nome_prodotto; ?></h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <label for="nome">Nome</label>
        <input type="text" name="nome" required><br>
        <label for="email">Email</label>
        <input type="email" name="email" required><br>
        <label for="numero_carta">Numero Carta di Credito</label>
        <input type="text" name="numero_carta" required><br>
        <label for="indirizzo">Indirizzo di Consegna</label>
        <textarea name="indirizzo" required></textarea><br>
        <label for="quantita">Quantità</label>
        <input type="number" name="quantita" value="1" min="1" required><br>
        <input type="submit" value="Acquista">
    </form>
</body>

</html>

